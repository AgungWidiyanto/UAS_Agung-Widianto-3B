<?php
session_start();
if (!isset($_SESSION['login'])) {
    header('location:index.php');
    exit;
}

require 'function.php';

// Periksa apakah parameter nim telah diterima
if (isset($_GET['nim'])) {
    $nim = $_GET['nim'];

    // Ambil data mahasiswa berdasarkan nim
    $mahasiswa = query("SELECT * FROM mahasiswa WHERE nim = '$nim'")[0];

    // Cetak informasi mahasiswa
    echo "Nama: " . $mahasiswa['nama'] . "<br>";
    echo "NIM: " . $mahasiswa['nim'] . "<br>";
    echo "Kelas: " . $mahasiswa['kelas'] . "<br>";
    echo "Jurusan: " . $mahasiswa['jurusan'] . "<br>";
    echo "Semester: " . $mahasiswa['semester'] . "<br>";

    // Tambahkan informasi lain yang ingin dicetak

} else {
    // Jika parameter nim tidak ditemukan
    echo "NIM tidak valid";
}
?>
