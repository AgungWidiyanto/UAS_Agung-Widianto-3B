<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <!-- Font Google -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Righteous&display=swap" rel="stylesheet">
    <!-- Own CSS -->
    <link rel="stylesheet" href="css/style.css">

    <title>Dashboard Mahasiswa</title>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark text-uppercase">
        <div class="container">
            <a class="navbar-brand" href="#">Dashboard Mahasiswa</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="log.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Close Navbar -->

    <!-- Container -->
    <div class="container mt-5">
        <div class="row">
            <div class="col-md">
                <h2 class="text-center fw-bold mb-4">Sejarah Fakultas Sains Dan teknologi</h2>
                <img src="https://static.promediateknologi.id/crop/0x0:0x0/0x0/webp/photo/p2/13/2023/11/13/IMG-20231113-WA0024-3050054745.jpg" width="100%"><br>
                
                <br><p>Bahwa dalam rangka memenuhi tuntutan perkembangan ilmu pengetahuan dan teknologi dan proses integrasi ilmu Agama Islam dengan berbagai rumpun ilmu pengetahuan serta mewujudkan sumber daya manusia yang berkualitas, Maka IAIN STS Jambi bertranformasi menjadi UIN STS Jambi dengan ditetapkan Peraturan Presiden Nomor 37 Tahun 2017 tentang Universitas Islam Negeri Sulthan Thaha Saifuddin Jambi, diizinkan membuka Prodi Umum dengan diterbitnya Keputusan Menteri Riset, Teknologi, dan Pendidikan TinggiRI Nomor 1178/KPT/I2018 Tentang Izin Pembukaan Program Studi (Prodi Fisika, Prodi Fisika dan Prodi Sistem Informasi) pada Universitas Islam Negeri Sulthan Thaha Saifuddin Jambi, dan selanjutnya pada Desember 2019 disetujui  Organsiasi Tata Kelola  Fakultas Sains dan Teknologi UIN STS Jambi oleh MenPanRB RI yang dituangkan ke dalam Peraturan Menteri Agama Republik Indonesia Nomor 38 Tahun 2019 tentang Perubahan atas Peraturan Menteri Agama Nomor 21 tahun 2017 tentang Organisasi dan Tata Kerja Universitas Islam Negeri Sulthan Thaha Saifuddin Jambi, dengan Visi “Menjadi Universitas sebagai Lokomotif Perubahan Sosial Islami Unggul Nasional menuju Internatuional dengan semangat Moderasi Entrepreneurship Islam”. Untuk mengelola fakultas baru, maka dipilih dan dilantiklah kepengurusan Dekan dan Wakil Dekan Periode 2019 s/d 2023 berdasarkan Keputusan  Rektor UIN STS Jambi (Prof.Dr.H.Su’adi, MA.,Ph.D). Untuk Fakultas Sainstek unsur pimpinan fakultas perdana  adalah Iskandar, S.Ag.,M.Pd.,M.S.I.Ph.D (Dekan), Dr. Tanti.,S.Si., M.Si. (Wadek Bid. Akademik, Kelembagaan, dan Kemahasiwaan) dan Dr. Abd Malik, S.Ag.,M.Si. (Wadek  Bid. Adm. Keuangan dan Kepegawaian). Sejak  Januari tahun 2020 Fakutlas Saintek UIN STS Jambi resmi melakukan operasional pelayanan akademik yaitu melayani proses perkuliahan Angkatan I (Pertama) Fakultas Saintek dengan 3 Program Studi yaitu: (Kimia, Fisika dan  Sistem Informasi) pada Semester Genap 2019/2020, 
                    <br>dan melakukan sosialiasi penerimaan mahasiswa baru Fakultas Saintek untuk 3 progam studi Fisika, Kimia dan Sistem Informasi  tahun akademik 2020/2021.</p>
                <!-- Tambahkan konten sejarah UIN Jambi di sini -->
            </div>
        </div>
    </div>
    <!-- Close Container -->

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
</body>

</html>
