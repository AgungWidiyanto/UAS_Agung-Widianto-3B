<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>FORM LOGIN MAHASISWA UIN</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
<link rel="icon" href="https://a.top4top.io/p_2470xg3rj1.png" type="image/x-icon"/>
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="https://cdn.prinsh.com/NathanPrinsley-textstyle/nprinsh-stext.css"/>
</head>
<body class="bg-blue">
    <header>
        <div class="jumbotron jumbotron-fluid">
<center><h1 style="font-size: 4"><font color="blue"><b>SELAMAT DATANG DI <br>FORM PENGISIAN DATA MAHASISWA</b></h1></font><h4>UIN SULTHAN THAHA SAIFUDDIN JAMBI</h4></center>
 </div>
</div>
</div>
</div>
    </header>
    <section>   
        <div class="col-md-12">
    <center><img class="img img-responsive" src="https://upload.wikimedia.org/wikipedia/commons/0/0d/Logo_UIN_STS_Jambi.jpg" width="14%" /><br><br>
<div class="col-md-4">
<a href="login.php" class="btn btn-primary mb-2">Login Admin</a>
		<table class="table table-bordered mt-4" id="myTable">
        <a href="loginmhs.php" class="btn btn-primary mb-2">Login Mahasiswa</a>
		<table class="table table-bordered mt-4" id="myTable">
                        </center>
                    </div>
    </section>
</body>
</html>