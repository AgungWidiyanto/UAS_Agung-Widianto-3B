<a href="home.php" onclick="return confirm('Apakah anda yakin ingin keluar ?')">


<center><h1>Logout ?</h1></center>

</a>